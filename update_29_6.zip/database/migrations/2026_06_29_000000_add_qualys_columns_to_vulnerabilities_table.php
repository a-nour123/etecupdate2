<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AddQualysColumnsToVulnerabilitiesTable extends Migration
{
    /**
     * Columns added to store the extra Qualys VM scan fields that have no
     * natural existing column on the vulnerabilities table.
     *
     * @var array<int, string>
     */
    private array $columns = [
        'network',
        'tracking_method',
        'ip_status',
        'fqdn',
        'ssl',
        'vendor_reference',
        'pci_vuln',
        'ticket_state',
        'instance',
        'qds',
        'trurisk_score',
        'associated_malware',
    ];

    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('vulnerabilities', function (Blueprint $table) {
            foreach ($this->columns as $column) {
                if (!Schema::hasColumn('vulnerabilities', $column)) {
                    $table->text($column)->nullable();
                }
            }
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('vulnerabilities', function (Blueprint $table) {
            foreach ($this->columns as $column) {
                if (Schema::hasColumn('vulnerabilities', $column)) {
                    $table->dropColumn($column);
                }
            }
        });
    }
}

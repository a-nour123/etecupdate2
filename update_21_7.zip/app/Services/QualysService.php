<?php

namespace App\Services;

use App\Models\QualysAuth;
use Illuminate\Support\Facades\Log;
use Illuminate\Http\Client\PendingRequest;
use Illuminate\Http\Client\Response;
use Illuminate\Support\Facades\Http;


class QualysService
{
  
    public const DEFAULT_QUALYS_BASE_URL = 'https://qualysapi.qg1.apps.qualysksa.com';

    /** Qualys VM Scan API path (launch, list, fetch, …). */
    public const FO_SCAN_PATH = '/api/2.0/fo/scan/';

    /** List / manage scan schedules. */
    public const FO_SCHEDULE_SCAN_PATH = '/api/2.0/fo/schedule/scan/';

    /** VM scan summary (alternative to legacy scan summary). */
    public const FO_VM_SCAN_SUMMARY_PATH = '/api/2.0/fo/scan/vm/summary/';

    public const ASSETVIEW_DATALIST_FIELDS = [
        'cve',
        'cveDescription',
        'cvssv2Base',
        'cvssv3Base',
        'CVSSRatingLabels',
        'qid',
        'title',
        'severity',
        'kbSeverity',
        'typeDetected',
        'lastDetected',
        'firstDetected',
        'protocol',
        'port',
        'vulnStatus',
        'assetId',
        'assetName',
        'assetIp',
        'tags',
        'solution',
        'results',
        'disabled',
        'ignored',
        'qvsScore',
        'detectionAge',
        'publishedDate',
        'patchReleased',
        'category',
        'rti',
        'operatingSystem',
        'lastFixed',
        'lastReopened',
        'timesFound',
        'threat',
        'isQualysPatchable',
        'assetCriticalScore',
        'assetRiskScore',
        'vulnTags.name',
    ];

    protected $baseUrl;
    protected $username;
    protected $password;
    private $limit = 10;

    public function __construct()
    {
        $setting = QualysAuth::first();
        $this->username = $setting ? $setting->username : null;
        $this->password = $setting ? $setting->password : null;
        $apiUrl = $setting ? trim($setting->api_url ?? '') : '';
        $this->baseUrl = $apiUrl !== '' ? rtrim($apiUrl, '/') : self::DEFAULT_QUALYS_BASE_URL;

        Log::info('QualysService constructed', [
            'user_loaded' => !empty($this->username),
            'username' => $this->username,
            'base_url' => $this->baseUrl,
            'using_default_url' => $apiUrl === '',
        ]);
    }

    public function getBaseUrl(): string
    {
        return $this->baseUrl;
    }

  
    public function url(string $path): string
    {
        return $this->baseUrl . (isset($path[0]) && $path[0] === '/' ? $path : '/' . $path);
    }


    public function getAssetViewDatalistFieldsQueryValue(): string
    {
        return implode(',', self::ASSETVIEW_DATALIST_FIELDS);
    }

    /**
     * @return array<string, string>
     */
    protected function emptyAssetViewRow(): array
    {
        return array_fill_keys(self::ASSETVIEW_DATALIST_FIELDS, '');
    }


    protected function scanFetchString(array $node, array $candidates): string
    {
        foreach ($candidates as $c) {
            if (!array_key_exists($c, $node) || $node[$c] === null || $node[$c] === '') {
                continue;
            }
            $v = $node[$c];
            if (is_array($v)) {
                $flat = [];
                array_walk_recursive($v, function ($x) use (&$flat) {
                    $flat[] = (string) $x;
                });

                return implode(',', array_filter($flat, static function ($s) {
                    return $s !== '';
                }));
            }

            return (string) $v;
        }

        return '';
    }

    protected function mapScanFetchNodeToAssetViewRow(array $node, array $hostContext = []): array
    {
        $row = $this->emptyAssetViewRow();
        $row['cve'] = $this->scanFetchString($node, ['cve_id', 'CVE_ID', 'cve', 'CVE']);
        $row['cveDescription'] = $this->scanFetchString($node, ['cveDescription', 'CVE_DESCRIPTION']);
        if ($row['cveDescription'] === '') {
            $row['cveDescription'] = \Illuminate\Support\Str::limit(
                $this->scanFetchString($node, ['results', 'RESULTS']),
                2000,
                ''
            );
        }
        $row['cvssv2Base'] = $this->scanFetchString($node, ['cvss_base', 'CVSS_BASE', 'cvssv2Base']);
        $row['cvssv3Base'] = $this->scanFetchString($node, ['cvss3_base', 'CVSS3_BASE', 'cvss3Base', 'cvss3_temporal', 'CVSS3_TEMPORAL']);
        $row['CVSSRatingLabels'] = $this->scanFetchString($node, ['CVSSRatingLabels', 'cvss_rating_labels']);
        $row['qid'] = $this->scanFetchString($node, ['qid', 'QID']);
        $row['title'] = $this->scanFetchString($node, ['title', 'TITLE']);
        $row['severity'] = $this->scanFetchString($node, ['severity', 'SEVERITY']);
        $row['kbSeverity'] = $this->scanFetchString($node, ['kbSeverity', 'KB_SEVERITY', 'kb_severity']);
        $row['typeDetected'] = $this->scanFetchString($node, ['type', 'TYPE', 'typeDetected']);
        $row['lastDetected'] = $this->scanFetchString($node, ['lastDetected', 'LAST_DETECTED', 'last_detected']);
        $row['firstDetected'] = $this->scanFetchString($node, ['firstDetected', 'FIRST_DETECTED', 'first_detected']);
        $row['protocol'] = $this->scanFetchString($node, ['protocol', 'PROTOCOL']);
        $row['port'] = $this->scanFetchString($node, ['port', 'PORT']);
        $row['vulnStatus'] = $this->scanFetchString($node, ['vulnStatus', 'VULN_STATUS', 'status', 'STATUS']);
        $row['assetId'] = $this->scanFetchString($node, ['asset_id', 'assetId', 'HOST_ID', 'host_id'])
            ?: ($hostContext['assetId'] ?? '');
        $row['assetName'] = $this->scanFetchString($node, ['dns', 'DNS', 'netbios', 'NETBIOS', 'fqdn', 'FQDN', 'assetName'])
            ?: ($hostContext['assetName'] ?? '');
        $row['assetIp'] = $this->scanFetchString($node, ['ip', 'IP', 'assetIp'])
            ?: ($hostContext['assetIp'] ?? '');
        $row['tags'] = $this->scanFetchString($node, ['tags', 'TAGS', 'asset_tags'])
            ?: ($hostContext['tags'] ?? '');
        $row['solution'] = $this->scanFetchString($node, ['solution', 'SOLUTION']);
        $row['results'] = $this->scanFetchString($node, ['results', 'RESULTS']);
        $row['disabled'] = $this->scanFetchString($node, ['disabled', 'DISABLED']);
        $row['ignored'] = $this->scanFetchString($node, ['ignored', 'IGNORED']);
        $row['qvsScore'] = $this->scanFetchString($node, ['qvsScore', 'QVS_SCORE']);
        $row['detectionAge'] = $this->scanFetchString($node, ['detectionAge', 'DETECTION_AGE']);
        $row['publishedDate'] = $this->scanFetchString($node, ['publishedDate', 'PUBLISHED_DATE']);
        $row['patchReleased'] = $this->scanFetchString($node, ['patchReleased', 'PATCH_RELEASED']);
        $row['category'] = $this->scanFetchString($node, ['category', 'CATEGORY']);
        $row['rti'] = $this->scanFetchString($node, ['rti', 'RTI']);
        $row['operatingSystem'] = $this->scanFetchString($node, ['os', 'OS', 'operatingSystem'])
            ?: ($hostContext['operatingSystem'] ?? '');
        $row['lastFixed'] = $this->scanFetchString($node, ['lastFixed', 'LAST_FIXED']);
        $row['lastReopened'] = $this->scanFetchString($node, ['lastReopened', 'LAST_REOPENED']);
        $row['timesFound'] = $this->scanFetchString($node, ['timesFound', 'TIMES_FOUND', 'instance']);
        $row['threat'] = $this->scanFetchString($node, ['threat', 'THREAT']);
        $row['isQualysPatchable'] = $this->scanFetchString($node, ['isQualysPatchable', 'IS_QUALYS_PATCHABLE']);
        $row['assetCriticalScore'] = $this->scanFetchString($node, ['assetCriticalScore', 'ASSET_CRITICAL_SCORE']);
        $row['assetRiskScore'] = $this->scanFetchString($node, ['assetRiskScore', 'ASSET_RISK_SCORE', 'TruRisk']);
        $row['vulnTags.name'] = $this->scanFetchString($node, ['vulnTags.name', 'vuln_tags', 'VULN_TAGS']);

        $impact = $this->scanFetchString($node, ['impact', 'IMPACT', 'threat', 'THREAT']);

        return array_merge($row, ['impact' => $impact]);
    }

    public function qualysApi(): PendingRequest
    {
        Log::debug('Qualys qualysApi client ready', [
            'base_url' => $this->baseUrl,
            'username' => $this->username,
        ]);

        return Http::withHeaders([
            'X-Requested-With' => 'Curl Sample',
        ])
            ->withBasicAuth($this->username, $this->password)
            ->timeout(600);
    }

    public function fetchScanResultsJson(string $scanRef, array $extraFormFields = []): Response
    {
        $url = $this->url(self::FO_SCAN_PATH);
        $payload = array_merge([
            'action' => 'fetch',
            'scan_ref' => $scanRef,
            'output_format' => 'json_extended',
            'mode' => 'extended',
        ], $extraFormFields);

        Log::info('Qualys fetchScanResultsJson started', [
            'scan_ref' => $scanRef,
            'url' => $url,
            'extra_fields' => array_keys($extraFormFields),
        ]);
        $startedAt = microtime(true);

        try {
            $response = $this->qualysApi()
                ->asForm()
                ->post($url, $payload);
        } catch (\Throwable $e) {
            Log::error('Qualys fetchScanResultsJson exception', [
                'scan_ref' => $scanRef,
                'seconds' => round(microtime(true) - $startedAt, 2),
                'error' => $e->getMessage(),
            ]);
            throw $e;
        }

        Log::info('Qualys fetchScanResultsJson finished', [
            'scan_ref' => $scanRef,
            'status' => $response->status(),
            'successful' => $response->successful(),
            'body_length' => strlen($response->body()),
            'seconds' => round(microtime(true) - $startedAt, 2),
        ]);

        return $response;
    }

    public function listScanSchedules(array $query = []): Response
    {
        Log::info('Qualys listScanSchedules started', ['query' => $query]);
        $response = $this->qualysApi()
            ->get($this->url(self::FO_SCHEDULE_SCAN_PATH), array_merge(['action' => 'list'], $query));
        Log::info('Qualys listScanSchedules finished', [
            'status' => $response->status(),
            'body_length' => strlen($response->body()),
        ]);

        return $response;
    }

    public function fetchVmScanSummaryXml(array $query): Response
    {
        Log::info('Qualys fetchVmScanSummaryXml started', ['query' => $query]);
        $response = $this->qualysApi()
            ->get($this->url(self::FO_VM_SCAN_SUMMARY_PATH), array_merge([
                'action' => 'list',
                'output_format' => 'xml',
            ], $query));
        Log::info('Qualys fetchVmScanSummaryXml finished', [
            'status' => $response->status(),
            'body_length' => strlen($response->body()),
        ]);

        return $response;
    }


    public function launchVmScan(array $payload): Response
    {
        Log::info('Qualys launchVmScan started', [
            'payload_keys' => array_keys($payload),
        ]);
        $response = $this->qualysApi()
            ->asForm()
            ->post($this->url(self::FO_SCAN_PATH), array_merge($payload, [
                'action' => 'launch',
            ]));
        Log::info('Qualys launchVmScan finished', [
            'status' => $response->status(),
            'body_length' => strlen($response->body()),
        ]);

        return $response;
    }


    protected function flattenScanFetchJsonForImport($node, array $hostContext = []): array
    {
        if (!is_array($node)) {
            return [];
        }
        if ($node === []) {
            return [];
        }
        $node = $this->unwrapScanFetchJsonRoot($node);

        if ($this->isZeroIndexedList($node)) {
            $out = [];
            foreach ($node as $item) {
                $out = array_merge($out, $this->flattenScanFetchJsonForImport($item, $hostContext));
            }

            return $out;
        }

        $qidRaw = $node['qid'] ?? $node['QID'] ?? null;
        if ($qidRaw !== null && trim((string) $qidRaw) !== '') {
            return [$this->mapScanFetchNodeToAssetViewRow($node, $hostContext)];
        }

        $childArrays = 0;
        foreach ($node as $v) {
            if (is_array($v)) {
                ++$childArrays;
            }
        }

        $ip = $node['ip'] ?? $node['IP'] ?? null;
        if (($ip !== null && $ip !== '') && $childArrays > 0) {
            return $this->flattenScanFetchWithHostContext($node, $hostContext, (string) $ip);
        }

        $assetIp = $node['assetIp'] ?? $node['asset_ip'] ?? null;
        if (($assetIp !== null && $assetIp !== '') && $childArrays > 0) {
            return $this->flattenScanFetchWithHostContext($node, $hostContext, (string) $assetIp);
        }

        $out = [];
        foreach ($node as $child) {
            if (is_array($child)) {
                $out = array_merge($out, $this->flattenScanFetchJsonForImport($child, $hostContext));
            }
        }

        return $out;
    }

    protected function flattenScanFetchWithHostContext(array $node, array $hostContext, string $primaryIp): array
    {
        $nextHost = [
            'assetIp' => $primaryIp,
            'assetName' => (string) ($node['dns'] ?? $node['DNS'] ?? $node['netbios'] ?? $node['NETBIOS'] ?? $node['assetName'] ?? $hostContext['assetName'] ?? ''),
            'assetId' => (string) ($node['asset_id'] ?? $node['assetId'] ?? $node['HOST_ID'] ?? $node['host_id'] ?? $hostContext['assetId'] ?? ''),
            'operatingSystem' => (string) ($node['os'] ?? $node['OS'] ?? $hostContext['operatingSystem'] ?? ''),
            'tags' => (string) ($node['tags'] ?? $node['TAGS'] ?? $hostContext['tags'] ?? ''),
        ];
        $out = [];
        foreach ($node as $child) {
            if (is_array($child)) {
                $out = array_merge($out, $this->flattenScanFetchJsonForImport($child, $nextHost));
            }
        }

        return $out;
    }

    protected function unwrapScanFetchJsonRoot(array $node): array
    {
        if (count($node) !== 1) {
            return $node;
        }
        $inner = reset($node);
        if (!is_array($inner)) {
            return $node;
        }
        $key = (string) key($node);
        if (preg_match('/^(HOST_LIST|HOSTS|SCAN_RESULTS|DATA|RESPONSE)$/i', $key)) {
            return $this->unwrapScanFetchJsonRoot($inner);
        }

        return $node;
    }


    protected function isZeroIndexedList(array $node): bool
    {
        $n = count($node);
        if ($n === 0) {
            return true;
        }
        $i = 0;
        foreach (array_keys($node) as $k) {
            if ((int) $k !== $i) {
                return false;
            }
            ++$i;
        }

        return $i === $n;
    }

      public function fetchCSV()
    {
        Log::info('Qualys fetchCSV started', [
            'username' => $this->username,
            'base_url' => $this->baseUrl,
        ]);

        $session = curl_init();
         

        // === Step 1: Login ===
        $loginUrl = $this->url('/fo/user_login.php');
        Log::info('Qualys fetchCSV login request', ['url' => $loginUrl]);
        curl_setopt_array($session, [
            CURLOPT_URL => $loginUrl,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POST => true,
            CURLOPT_HEADER => true,
            CURLOPT_HTTPHEADER => [
                'Content-Type: application/x-www-form-urlencoded; charset=UTF-8',
                'Referer: ' . $this->baseUrl . '/qglogin/index.html',
                'Origin: ' . $this->baseUrl,
                'X-Requested-With: XMLHttpRequest',
                'User-Agent: Mozilla/5.0'
            ],
            CURLOPT_POSTFIELDS => http_build_query([
                'UserLogin' => $this->username,
                'UserPasswd' => $this->password,
                '_form_action1' => 'Please wait...',
                '_form_action' => 'Login',
                '_form_visited' => 1,
                'timezone' => 'Africa/Cairo',
                'gmtoffset' => -180,
                'timezone_abbr' => 'EEST',
                'is_dst' => 1
            ])
        ]);

        $loginResponse = curl_exec($session);
        if ($loginResponse === false) {
            Log::error('Qualys fetchCSV login curl failed', ['error' => curl_error($session)]);
            return response('Login failed: ' . curl_error($session), 500);
        }

        preg_match_all('/^Set-Cookie:\s*([^;]*)/mi', $loginResponse, $matches);
        $cookies = implode('; ', array_map('trim', $matches[1]));

        if (!str_contains($loginResponse, '"status":"true"')) {
            Log::error('Qualys fetchCSV login unexpected response', [
                'response_start' => substr((string) $loginResponse, 0, 300),
            ]);
            return response('Login failed: unexpected response', 500);
        }

        Log::info('Qualys fetchCSV login success', [
            'has_cookies' => $cookies !== '',
        ]);

        curl_reset($session);

        // === Step 2: Stream CSV ===
        $fields = $this->getAssetViewDatalistFieldsQueryValue();

        $csvUrl = $this->url('/portal-front/rest/assetview/1.0/assetvuln/v2/datalist/download/CSV') . '?' . http_build_query([
            'reportType' => 'CSV',
            'showCVECentric' => 'true',
            'fields' => $fields,
            'timezone' => 'Asia/Aden',
            'limit' => 100,
            'offset' => 0,
            'groupByPivot' => 'VM',
            'havingQuery' => 'vulnerabilities.found: TRUE',
            'query' => ''
        ]);

        Log::info('Qualys fetchCSV csv request', ['url_length' => strlen($csvUrl)]);
        curl_setopt_array($session, [
            CURLOPT_URL => $csvUrl,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_HTTPHEADER => [
                "Cookie: $cookies",
                'User-Agent: Mozilla/5.0',
                'Referer: ' . $this->baseUrl . '/',
                'X-Requested-With: XMLHttpRequest',
            ]
        ]);

        $csv = curl_exec($session);
        if (!$csv) {
            Log::error('Qualys fetchCSV csv curl failed', ['error' => curl_error($session)]);
            return response('CSV fetch failed: ' . curl_error($session), 500);
        }

        Log::info('Qualys fetchCSV csv received', ['bytes' => strlen($csv)]);

        $rows = preg_split('/\r\n|\n|\r/', $csv);
        $output = '';
        $headerMatched = false;
        $count = 0;

        $expectedHeader = [
            "CVE","CVE-Description","CVSSv2 Base (nvd)","CVSSv3.1 Base (nvd)","QID","Title","Severity","KB Severity",
            "Type Detected","Last Detected","First Detected","Protocol","Port","Status","Asset Id","Asset Name",
            "Asset IPV4","Asset IPV6","Solution","Asset Tags","Disabled","Ignored","QVS Score","Detection AGE",
            "Published Date","Patch Released","Category","CVSS Rating Labels","RTI","Operating System","Last Fixed",
            "Last Reopened","Times Detected","Threat","Vuln Patchable","Asset Critical Score","TruRisk Score",
            "Vulnerability Tags","Results"
        ];

        foreach ($rows as $line) {
            $parsed = str_getcsv($line);
            if (!$headerMatched && $parsed === $expectedHeader) {
                $output .= "<pre>" . implode(" | ", $parsed) . "\n";
                $output .= str_repeat('-', 20 * count($parsed)) . "\n";
                $headerMatched = true;
                continue;
            }

            if ($headerMatched && count($parsed) === count($expectedHeader)) {
                $output .= implode(" | ", $parsed) . "\n";
                if (++$count >= $this->limit) break;
            }
        }

        Log::info('Qualys fetchCSV parsed', [
            'header_matched' => $headerMatched,
            'row_count' => $count,
        ]);

        // === Step 3: Logout ===
        curl_setopt_array($session, [
            CURLOPT_URL => $this->url('/portal-front/rest/passport/logout') . '?',
            CURLOPT_HTTPHEADER => [
                "Cookie: $cookies",
                'User-Agent: Mozilla/5.0',
                'Referer: ' . $this->baseUrl . '/vm/',
                'Accept: /'
            ],
            CURLOPT_RETURNTRANSFER => true
        ]);

        curl_exec($session);
        curl_close($session);
        Log::info('Qualys fetchCSV finished');
        dd($output);

        return response($output . "</pre>", 200)
            ->header('Content-Type', 'text/html; charset=utf-8');
    }


    public function authenticate(bool $fetchScanVulnerabilities = true): array
    {
        Log::info('Qualys authenticate started', [
            'fetch_scan_vulnerabilities' => $fetchScanVulnerabilities,
            'username' => $this->username,
            'base_url' => $this->baseUrl,
        ]);
        $startedAt = microtime(true);

        try {
            $listUrl = $this->url(self::FO_SCAN_PATH);
            Log::info('Qualys authenticate scan list request', [
                'url' => $listUrl,
                'state' => 'Finished',
                'show_last' => 1,
            ]);

            $scanListResponse = $this->qualysApi()->get($listUrl, [
                'action' => 'list',
                'state' => 'Finished',
                'show_last' => 1,
            ]);

            Log::info('Qualys authenticate scan list response', [
                'status' => $scanListResponse->status(),
                'successful' => $scanListResponse->successful(),
                'body_length' => strlen($scanListResponse->body()),
            ]);

            if (!$scanListResponse->successful()) {
                throw new \Exception('Qualys scan list failed: HTTP ' . $scanListResponse->status());
            }

            $xml = @simplexml_load_string($scanListResponse->body());
            if ($xml === false) {
                throw new \Exception('Qualys scan list: response is not valid XML');
            }

            $scanRefs = [];
            $scans = [];
            if (isset($xml->RESPONSE->SCAN_LIST->SCAN)) {
                foreach ($xml->RESPONSE->SCAN_LIST->SCAN as $scan) {
                    $ref = (string) $scan->REF;
                    if ($ref === '') {
                        continue;
                    }
                    $scanRefs[] = $ref;
                    $scans[] = [
                        'ref' => $ref,
                        'title' => (string) ($scan->TITLE ?? ''),
                        'status' => (string) ($scan->STATUS ?? ''),
                        'type' => (string) ($scan->TYPE ?? ''),
                        'launch_datetime' => (string) ($scan->LAUNCH_DATETIME ?? ''),
                    ];
                }
            }

            Log::info('Qualys authenticate scans parsed', [
                'scan_count' => count($scanRefs),
                'scan_refs' => $scanRefs,
            ]);

            $fetchErrors = [];
            $vulns = [];
            if ($fetchScanVulnerabilities && $scanRefs !== []) {
                foreach ($scanRefs as $ref) {
                    Log::info('Qualys authenticate fetching scan', ['scan_ref' => $ref]);
                    try {
                        $fr = $this->fetchScanResultsJson($ref);
                    } catch (\Throwable $e) {
                        $fetchErrors[$ref] = 'exception:' . $e->getMessage();
                        Log::error('Qualys authenticate fetch exception', [
                            'scan_ref' => $ref,
                            'error' => $e->getMessage(),
                        ]);
                        continue;
                    }

                    if (!$fr->successful()) {
                        $fetchErrors[$ref] = $fr->status();
                        Log::warning('Qualys authenticate fetch unsuccessful', [
                            'scan_ref' => $ref,
                            'status' => $fr->status(),
                        ]);

                        continue;
                    }
                    $raw = ltrim($fr->body());
                    if ($raw !== '' && $raw[0] === '<') {
                        $fetchErrors[$ref] = 'xml_or_html';
                        Log::warning('Qualys authenticate fetch returned xml/html', [
                            'scan_ref' => $ref,
                            'body_start' => substr($raw, 0, 200),
                        ]);

                        continue;
                    }
                    $decoded = $fr->json();
                    if (!is_array($decoded)) {
                        $fetchErrors[$ref] = 'invalid_json';
                        Log::warning('Qualys authenticate fetch invalid json', [
                            'scan_ref' => $ref,
                        ]);

                        continue;
                    }
                    $flattened = $this->flattenScanFetchJsonForImport($decoded);
                    Log::info('Qualys authenticate scan flattened', [
                        'scan_ref' => $ref,
                        'row_count' => count($flattened),
                    ]);
                    $vulns = array_merge($vulns, $flattened);
                }
            } else {
                Log::info('Qualys authenticate skipped fetch', [
                    'fetch_scan_vulnerabilities' => $fetchScanVulnerabilities,
                    'scan_count' => count($scanRefs),
                ]);
            }

            if ($vulns !== []) {
                Log::info('Qualys authenticate dispatching ImportQualysVulnJob', [
                    'vuln_count' => count($vulns),
                ]);
                dispatch(new \App\Jobs\ImportQualysVulnJob($vulns));
            } else {
                Log::info('Qualys authenticate no vulns to import');
            }

            $result = [
                'ok' => true,
                'scans' => $scans,
                'scan_refs' => $scanRefs,
                'imported_vulnerabilities' => count($vulns),
                'fetch_errors' => $fetchErrors,
            ];

            Log::info('Qualys authenticate completed', [
                'seconds' => round(microtime(true) - $startedAt, 2),
                'imported_vulnerabilities' => count($vulns),
                'fetch_errors' => $fetchErrors,
            ]);

            return $result;
        } catch (\Exception $e) {
            Log::error('Qualys authenticate exception', [
                'error' => $e->getMessage(),
                'seconds' => round(microtime(true) - $startedAt, 2),
            ]);

            return [
                'ok' => false,
                'error' => $e->getMessage(),
            ];
        }
    }


    public function getVulnerabilityCount()
{
    Log::info('Qualys getVulnerabilityCount started');
    try {
        $batchSize = 3;
        $baseUrl = $this->url('/api/2.0/fo/asset/host/vm/detection/');
        $lastId = 0;
        $maxAttempts = 3; // Safety limit for total records
        $attempts = 0;
        $batch = [];

        while ($attempts < $maxAttempts) {
            $attempts++;

            // Build URL with pagination
            $urlParams = [
                'action' => 'list',
                'truncation_limit' => 1,
                'id_min' => $lastId + 1
            ];

            Log::info('Qualys getVulnerabilityCount page request', [
                'attempt' => $attempts,
                'url_params' => $urlParams,
            ]);

            $response = $this->qualysApi()
                ->asForm()
                ->get($baseUrl, $urlParams);

            Log::info('Qualys getVulnerabilityCount page response', [
                'attempt' => $attempts,
                'status' => $response->status(),
                'body_length' => strlen($response->body()),
            ]);

            $xml = simplexml_load_string($response->body());

            // Check if we got valid data
            if (!isset($xml->RESPONSE->HOST_LIST->HOST)) {
                Log::info('Qualys getVulnerabilityCount no more hosts', ['attempt' => $attempts]);
                break; // No more records
            }

            $host = $xml->RESPONSE->HOST_LIST->HOST;
            $currentId = (int)$host->ID;

            // Only process if this is a new record
            if ($currentId > $lastId) {
                $lastId = $currentId;

                $detections = [];
                if (isset($host->DETECTION_LIST->DETECTION)) {
                    foreach ($host->DETECTION_LIST->DETECTION as $det) {
                        $detections[] = json_decode(json_encode($det), true);
                    }
                }

                Log::info('Qualys getVulnerabilityCount host parsed', [
                    'host_id' => $currentId,
                    'detection_count' => count($detections),
                ]);

                $batch[] = [
                    'host_id' => (string)$host->ID,
                    'ip' => (string)$host->IP,
                    'os' => (string)$host->OS,
                    'last_scan' => (string)$host->LAST_SCAN_DATETIME,
                    'detections' => $detections,
                ];

                // Dispatch batch when we reach batch size
                if (count($batch) >= $batchSize) {
                    // ProcessVulnerabilityBatch::dispatch($batch);
                    //    dispatch(new ProcessVulnerabilityBatch($batch))->delay(now()->addSeconds(10));
                    Log::info('Qualys getVulnerabilityCount batch cleared', [
                        'batch_size' => count($batch),
                    ]);
                    $batch = []; // Reset batch
                }
            } else {
                // ID didn't increase - we're stuck
                Log::warning('Qualys getVulnerabilityCount stuck on host id', [
                    'last_id' => $lastId,
                    'current_id' => $currentId,
                ]);
                break;
            }
        }

        // Dispatch any remaining records in partial batch
        if (!empty($batch)) {
//    dispatch(new ProcessVulnerabilityBatch($batch))->delay(now()->addSeconds(10));
            Log::info('Qualys getVulnerabilityCount remaining batch', [
                'batch_size' => count($batch),
            ]);
        }

        Log::info('Qualys getVulnerabilityCount completed', ['processed' => $attempts]);

        return ['success' => true, 'processed' => $attempts];
    } catch (\Exception $e) {
        Log::error('Qualys getVulnerabilityCount exception', ['error' => $e->getMessage()]);
        return ['error' => $e->getMessage()];
    }
}


}

<?php

namespace App\Jobs;

use App\Models\Vulnerability;
use Carbon\Carbon;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\Log;

class ImportQualysVulnJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    /** Keys mapped to core {@see Vulnerability} columns (not repeated in overflow block). */
    private const MAPPED_KEYS = [
        'title', 'cve', 'cveDescription', 'impact', 'severity', 'solution', 'qid',
        'protocol', 'port', 'assetIp', 'assetName', 'threat', 'category',
        'firstDetected', 'lastDetected', 'publishedDate', 'results',
        'cvssv2Base', 'cvssv3Base', 'patchReleased', 'kbSeverity',
        'operatingSystem', 'CVSSRatingLabels',
        'vulnStatus', 'typeDetected', 'assetId', 'tags', 'timesFound',
        'qvsScore', 'detectionAge', 'rti', 'isQualysPatchable', 'vulnTags.name',
        'assetCriticalScore', 'assetRiskScore', 'lastFixed', 'lastReopened',
        'disabled', 'ignored',
    ];

    /** @var array<int, array<string, string>> */
    protected $vulns;

    /**
     * @param array<int, array<string, string>> $vulns Rows from Qualys; see {@see \App\Services\QualysService::ASSETVIEW_DATALIST_FIELDS}
     */
    public function __construct(array $vulns)
    {
        $this->vulns = $vulns;
        Log::info('ImportQualysVulnJob constructed', [
            'vuln_count' => count($vulns),
        ]);
    }

    /**
     * @return void
     */
    public function handle()
    {
        $total = count($this->vulns);
        $saved = 0;
        $skipped = 0;
        $failed = 0;

        Log::info('ImportQualysVulnJob started', ['vuln_count' => $total]);

        foreach ($this->vulns as $vuln) {
            $qid = array_key_exists('qid', $vuln) ? trim((string) $vuln['qid']) : '';
            if ($qid === '') {
                ++$skipped;
                continue;
            }
            try {
                $pluginId = (string) $qid;
                $firstDiscovered = $this->parseQualysDate($vuln['firstDetected'] ?? '');

                $match = [
                    'plugin_id' => $pluginId,
                    'first_discovered' => $firstDiscovered,
                ];

                $model = Vulnerability::firstOrNew($match);
                $wasExisting = $model->exists;

                $values = $this->mapQualysRowToAttributes($vuln, $wasExisting ? $model : null);
                if (!$wasExisting) {
                    $values['created_by'] = 1;
                }

                $model->fill($values);
                $model->save();
                ++$saved;

                Log::debug('ImportQualysVulnJob row saved', [
                    'qid' => $qid,
                    'was_existing' => $wasExisting,
                    'asset_ip' => $vuln['assetIp'] ?? null,
                ]);
            } catch (\Throwable $e) {
                ++$failed;
                Log::error('ImportQualysVulnJob: failed to store row', [
                    'qid' => $qid,
                    'error' => $e->getMessage(),
                ]);
            }
        }

        Log::info('ImportQualysVulnJob completed', [
            'total' => $total,
            'saved' => $saved,
            'skipped' => $skipped,
            'failed' => $failed,
        ]);
    }

    /**
     * Map Qualys row into standard {@see Vulnerability} columns only (no separate Qualys table/columns/JSON).
     *
     * @param array<string, string> $v
     * @return array<string, mixed>
     */
    protected function mapQualysRowToAttributes(array $v, ?Vulnerability $existing = null): array
    {
        $title = $v['title'] ?? 'Qualys Vuln';
        $descParts = array_filter([
            $v['cveDescription'] ?? '',
            $v['impact'] ?? '',
        ]);
        $coreDescription = trim(implode("\n\n", $descParts)) ?: ($v['results'] ?? '');
        $overflow = $this->formatQualysOverflowBlock($v);
        $newDescription = trim($coreDescription . ($overflow !== '' ? "\n\n--- Qualys ---\n" . $overflow : ''));
        $description = $existing
            ? $this->appendTextBlock($existing->description, $newDescription !== '' ? $newDescription : null)
            : ($newDescription !== '' ? $newDescription : null);

        $port = $v['port'] ?? '';
        $portInt = ($port !== '' && is_numeric($port)) ? (int) $port : null;

        $assetIp = $v['assetIp'] ?? '';
        $ipV4 = filter_var($assetIp, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4) ? $assetIp : null;

        $firstDiscovered = $this->parseQualysDate($v['firstDetected'] ?? '');
        $lastObserved = $this->parseQualysDate($v['lastDetected'] ?? '');

        if ($existing && $lastObserved !== null) {
            $lastObserved = $this->maxDateTimeString($existing->last_observed, $lastObserved);
        }

        $results = $this->nullIfEmpty($v['results'] ?? null);
        $pluginOutputParts = array_filter([
            $results,
            ($assetIp !== '' && $ipV4 === null) ? 'Asset IP: ' . $assetIp : null,
        ]);
        $pluginOutput = $pluginOutputParts !== [] ? implode("\n\n", $pluginOutputParts) : null;

        $row = [
            'name' => mb_substr($title, 0, 255),
            'cve' => $this->nullIfEmpty($v['cve'] ?? null),
            'description' => $description,
            'severity' => $this->normalizeQualysSeverity($v['severity'] ?? ''),
            'recommendation' => $this->nullIfEmpty($v['solution'] ?? null),
            'plan' => null,
            'status' => 'Open',
            'plugin_id' => (string) $v['qid'],
            'protocol' => $this->nullIfEmpty($v['protocol'] ?? null),
            'port' => $portInt,
            'ip_address' => $ipV4,
            'dns_name' => $this->nullIfEmpty($v['assetName'] ?? null),
            'synopsis' => $this->nullIfEmpty($v['threat'] ?? $v['category'] ?? null),
            'first_discovered' => $firstDiscovered,
            'last_observed' => $lastObserved,
            'plugin_publication_date' => $this->parseQualysDate($v['publishedDate'] ?? ''),
            'plugin_modification_date' => null,
            'plugin_output' => $pluginOutput,
            'cvss_v2' => $this->nullIfEmpty($v['cvssv2Base'] ?? null),
            'cvss_v3' => $this->nullIfEmpty($v['cvssv3Base'] ?? null),
            'patch_publication' => $this->nullIfEmpty($v['patchReleased'] ?? null),
            'risk_factor' => $this->nullIfEmpty($v['kbSeverity'] ?? null),
            'cpe' => $this->nullIfEmpty($v['operatingSystem'] ?? null),
            'cross_reference' => $this->nullIfEmpty($v['CVSSRatingLabels'] ?? null),
            'family' => $this->nullIfEmpty($v['category'] ?? null),
            'service' => $this->nullIfEmpty($v['vulnStatus'] ?? null),
            'agent_id' => $this->nullIfEmpty($v['assetId'] ?? null),
            'version' => $this->nullIfEmpty($v['timesFound'] ?? null),
            'check_type' => $this->nullIfEmpty($v['typeDetected'] ?? null),
            'see_also' => $this->nullIfEmpty($v['tags'] ?? null),
            'vuln_priority_rating' => $this->nullIfEmpty($v['qvsScore'] ?? null),
            'stig_severity' => $this->nullIfEmpty($v['detectionAge'] ?? null),
            'exploit_ease' => $this->nullIfEmpty($v['rti'] ?? null),
            'exploit_framework' => $this->nullIfEmpty($v['isQualysPatchable'] ?? null),
            'recast_risk_comment' => $this->nullIfEmpty($v['vulnTags.name'] ?? null),
            'acr' => $this->nullIfEmpty($v['assetCriticalScore'] ?? null),
            'aes' => $this->nullIfEmpty($v['assetRiskScore'] ?? null),
            'plus_modification' => $this->nullIfEmpty($v['lastFixed'] ?? null),
            'severity_end_of_life' => $this->nullIfEmpty($v['lastReopened'] ?? null),
            'tenable_status' => 'Qualys',
        ];

        $stepLines = array_filter([
            $this->nullIfEmpty($v['disabled'] ?? null) !== null ? 'disabled: ' . trim((string) $v['disabled']) : null,
            $this->nullIfEmpty($v['ignored'] ?? null) !== null ? 'ignored: ' . trim((string) $v['ignored']) : null,
        ]);
        if ($stepLines !== []) {
            $row['steps_to_remediate'] = implode("\n", $stepLines);
        }

        if ($existing === null) {
            $row['created_by'] = 1;
        }

        return $row;
    }

    /**
     * Extra Qualys fields as readable lines (for description tail).
     *
     * @param array<string, string> $v
     */
    protected function formatQualysOverflowBlock(array $v): string
    {
        $lines = [];
        foreach ($v as $key => $value) {
            if (in_array($key, self::MAPPED_KEYS, true)) {
                continue;
            }
            if ($value === null || $value === '') {
                continue;
            }
            $lines[] = $key . ': ' . (string) $value;
        }

        return implode("\n", $lines);
    }

    protected function appendTextBlock(?string $existing, ?string $addition): ?string
    {
        $addition = $addition !== null ? trim($addition) : '';
        if ($addition === '') {
            return $existing !== null && trim($existing) !== '' ? $existing : null;
        }
        $existing = $existing !== null ? trim($existing) : '';
        if ($existing === '') {
            return $addition;
        }
        if (str_contains($existing, $addition)) {
            return $existing;
        }

        return $existing . "\n\n---\n\n" . $addition;
    }

    protected function maxDateTimeString($current, string $candidate): string
    {
        if ($current === null || $current === '') {
            return $candidate;
        }
        try {
            $a = Carbon::parse($current);
            $b = Carbon::parse($candidate);

            return $b->greaterThan($a) ? $candidate : $current;
        } catch (\Throwable $e) {
            return $candidate;
        }
    }

    protected function nullIfEmpty(?string $s): ?string
    {
        if ($s === null) {
            return null;
        }
        $t = trim($s);

        return $t === '' ? null : $t;
    }

    protected function parseQualysDate(?string $s): ?string
    {
        if ($s === null || trim($s) === '') {
            return null;
        }
        try {
            return Carbon::parse($s)->format('Y-m-d H:i:s');
        } catch (\Throwable $e) {
            return null;
        }
    }

    protected function normalizeQualysSeverity(string $raw): string
    {
        $s = trim($raw);
        if ($s === '') {
            return 'Low';
        }
        $byNumber = [
            '1' => 'Informational',
            '2' => 'Low',
            '3' => 'Medium',
            '4' => 'High',
            '5' => 'Critical',
        ];
        if (isset($byNumber[$s])) {
            return $byNumber[$s];
        }
        $lower = strtolower($s);
        $byWord = [
            'informational' => 'Informational',
            'info' => 'Informational',
            'low' => 'Low',
            'medium' => 'Medium',
            'high' => 'High',
            'critical' => 'Critical',
            'severe' => 'Critical',
        ];
        if (isset($byWord[$lower])) {
            return $byWord[$lower];
        }
        $uc = ucfirst($lower);
        $allowed = ['Critical', 'High', 'Medium', 'Low', 'Informational'];
        if (in_array($uc, $allowed, true)) {
            return $uc;
        }
        if (in_array($s, $allowed, true)) {
            return $s;
        }

        return 'Low';
    }
}

<?php

namespace App\Jobs;

use App\Models\QualysSyncHistory;
use App\Services\QualysService;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\Log;

class SyncQualysJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public $timeout = 7200;

    protected $historyId;

    public function __construct(int $historyId)
    {
        $this->historyId = $historyId;
    }

    public function handle(): void
    {
        set_time_limit(0);

        $history = QualysSyncHistory::find($this->historyId);
        if (!$history) {
            Log::error('SyncQualysJob: history record not found', ['id' => $this->historyId]);
            return;
        }

        $service = new QualysService();
        Log::info('SyncQualysJob started', ['history_id' => $this->historyId]);

        try {
            $this->fetchAllVmDetections($service, $history);
        } catch (\Throwable $e) {
            $history->update([
                'status' => 2,
                'error' => mb_substr($e->getMessage(), 0, 1000),
            ]);
            Log::error('SyncQualysJob failed', [
                'history_id' => $this->historyId,
                'error' => $e->getMessage(),
            ]);
        }
    }

    protected function fetchAllVmDetections(QualysService $service, QualysSyncHistory $history): void
    {
        $detectionPath = '/api/2.0/fo/asset/host/vm/detection/';
        $lastId = 0;
        $pageSize = 100;
        $maxPages = 50000;
        $totalImported = 0;
        $totalFailed = 0;
        $totalProcessed = 0;

        for ($page = 1; $page <= $maxPages; $page++) {
            $idMin = $lastId > 0 ? $lastId + 1 : 1;
            $response = $this->callDetectionApi($service, $detectionPath, $idMin, $pageSize);

            if (!$response->successful()) {
                throw new \RuntimeException('Qualys detection page failed: HTTP ' . $response->status());
            }

            $xml = @simplexml_load_string($response->body());
            if ($xml === false) {
                throw new \RuntimeException('Qualys detection page returned invalid XML');
            }

            if ($page === 1 && $history->total === null) {
                $totalHint = $this->extractTotalFromXml($xml);
                if ($totalHint > 0) {
                    $history->update(['total' => $totalHint]);
                    $history->total = $totalHint;
                }
            }

            if (!isset($xml->RESPONSE->HOST_LIST->HOST)) {
                break;
            }

            $hosts = $xml->RESPONSE->HOST_LIST->HOST;
            $hostList = [];
            if (isset($hosts->ID)) {
                $hostList = [$hosts];
            } else {
                foreach ($hosts as $h) {
                    $hostList[] = $h;
                }
            }

            if ($hostList === []) {
                break;
            }

            $maxHostId = $lastId;
            $vulnBatch = [];

            foreach ($hostList as $host) {
                $hostId = (int) ($host->ID ?? 0);
                if ($hostId > $maxHostId) {
                    $maxHostId = $hostId;
                }

                $detections = [];
                if (isset($host->DETECTION_LIST->DETECTION)) {
                    $dets = $host->DETECTION_LIST->DETECTION;
                    if (isset($dets->QID)) {
                        $detections = [$dets];
                    } else {
                        foreach ($dets as $d) {
                            $detections[] = $d;
                        }
                    }
                }

                foreach ($detections as $det) {
                    $qid = trim((string) ($det->QID ?? ''));
                    if ($qid === '') {
                        continue;
                    }

                    $vulnBatch[] = [
                        'qid' => $qid,
                        'title' => 'QID ' . $qid,
                        'severity' => (string) ($det->SEVERITY ?? ''),
                        'kbSeverity' => (string) ($det->SEVERITY ?? ''),
                        'typeDetected' => (string) ($det->TYPE ?? ''),
                        'lastDetected' => (string) ($det->LAST_FOUND_DATETIME ?? ''),
                        'firstDetected' => (string) ($det->FIRST_FOUND_DATETIME ?? ''),
                        'protocol' => (string) ($det->PROTOCOL ?? ''),
                        'port' => (string) ($det->PORT ?? ''),
                        'vulnStatus' => (string) ($det->STATUS ?? ''),
                        'assetId' => (string) ($host->ID ?? ''),
                        'assetName' => (string) ($host->DNS ?? $host->NETBIOS ?? ''),
                        'assetIp' => (string) ($host->IP ?? ''),
                        'operatingSystem' => (string) ($host->OS ?? ''),
                        'results' => (string) ($det->RESULTS ?? ''),
                        'timesFound' => (string) ($det->TIMES_FOUND ?? ''),
                        'disabled' => (string) ($det->IS_DISABLED ?? ''),
                        'ignored' => (string) ($det->IS_IGNORED ?? ''),
                        'cve' => '',
                        'cveDescription' => '',
                        'cvssv2Base' => '',
                        'cvssv3Base' => '',
                        'CVSSRatingLabels' => '',
                        'tags' => '',
                        'solution' => '',
                        'qvsScore' => '',
                        'detectionAge' => '',
                        'publishedDate' => '',
                        'patchReleased' => '',
                        'category' => '',
                        'rti' => '',
                        'lastFixed' => '',
                        'lastReopened' => '',
                        'threat' => '',
                        'isQualysPatchable' => '',
                        'assetCriticalScore' => '',
                        'assetRiskScore' => '',
                        'vulnTags.name' => '',
                    ];
                }

                ++$totalProcessed;
            }

            if ($vulnBatch !== []) {
                dispatch(new ImportQualysVulnJob($vulnBatch));
                $totalImported += count($vulnBatch);
            }

            $history->update([
                'processed' => $totalProcessed,
                'imported' => $totalImported,
                'failed' => $totalFailed,
                'total' => $history->total ?: null,
            ]);

            Log::info('SyncQualysJob page done', [
                'page' => $page,
                'hosts_in_page' => count($hostList),
                'vulns_in_page' => count($vulnBatch),
                'total_processed' => $totalProcessed,
                'last_host_id' => $maxHostId,
            ]);

            if ($maxHostId <= $lastId) {
                break;
            }
            $lastId = $maxHostId;

            if (count($hostList) < $pageSize) {
                break;
            }
        }

        $history->update([
            'status' => 0,
            'processed' => $totalProcessed,
            'imported' => $totalImported,
            'failed' => $totalFailed,
            'total' => $history->total ?: $totalProcessed,
        ]);

        Log::info('SyncQualysJob completed', [
            'history_id' => $this->historyId,
            'total_hosts' => $totalProcessed,
            'total_vulns_imported' => $totalImported,
        ]);
    }

    protected function callDetectionApi(QualysService $service, string $path, int $idMin, int $pageSize)
    {
        return $service->qualysApi()->get($service->url($path), [
            'action' => 'list',
            'truncation_limit' => $pageSize,
            'id_min' => $idMin,
            'show_results' => 1,
        ]);
    }

    protected function extractTotalFromXml($xml): int
    {
        if (isset($xml->RESPONSE->WARNING->TEXT)) {
            $text = (string) $xml->RESPONSE->WARNING->TEXT;
            if (preg_match('/(\d+)\s+total\s+host/i', $text, $m)) {
                return (int) $m[1];
            }
        }

        return 0;
    }
}

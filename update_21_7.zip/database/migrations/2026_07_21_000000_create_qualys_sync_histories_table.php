<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateQualysSyncHistoriesTable extends Migration
{
    public function up()
    {
        Schema::create('qualys_sync_histories', function (Blueprint $table) {
            $table->id();
            $table->string('type')->default('Vulnerability');
            $table->integer('processed')->default(0);
            $table->integer('total')->nullable();
            $table->integer('imported')->default(0);
            $table->integer('failed')->default(0);
            $table->tinyInteger('status')->default(1)->comment('1=running, 0=completed, 2=failed');
            $table->text('error')->nullable();
            $table->timestamps();
        });
    }

    public function down()
    {
        Schema::dropIfExists('qualys_sync_histories');
    }
}
